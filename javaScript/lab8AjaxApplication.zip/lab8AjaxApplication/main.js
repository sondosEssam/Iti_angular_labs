//selectors 
var tbody = document.getElementById("tbody");
var tr = document.createElement("tr");
var fetchUsersButton = document.getElementById("fetchUsers");


//global 
var xml = new XMLHttpRequest();
var users =[];


//apis

 function requests(method,url,body,isAsync){
    xml.open(method,url,isAsync);
    xml.send(body);
    xml.onreadystatechange = function(){
        if(xml.readyState === 4 && xml.status >= 200 && xml.status < 300){
             users =JSON.parse(xml.responseText);
            return users;
        }
    }
}

function getAllUsers(){

    var users = requests("GET","https://68b58c51e5dc090291af64bd.mockapi.io/api/v1/users","",true);
    console.log(users);
    
    return users;
}

//get all users
//  function getAllUsersAndAppendtTable(){
//     xml.open("GET","https://68b58c51e5dc090291af64bd.mockapi.io/api/v1/users");
//     xml.send();
//     xml.onreadystatechange = function(){
//         if(xml.readyState === 4 && xml.status === 200){
//             users = JSON.parse(xml.responseText);
//             for(var i =0; i<users.length;i++){
//             tr.innerHTML = `
//             <td>${users[i].id}</td>
//             <td>${users[i].name}</td>
//             <td>${users[i].email}</td>
//             <td>${users[i].userName}</td>
//             <td>${users[i].phone}</td>
//             `
//             tbody.appendChild(tr);
//             }
//         }
//     }
// }


//structure

function tableAppendUser(){
var users =getAllUsers();
console.log(users);

for(var i =0; i<users.length;i++){
    tr.innerHTML = `
    <td>${users[i].id}</td>
    <td>${users[i].name}</td>
    <td>${users[i].email}</td>
    <td>${users[i].userName}</td>
    <td>${users[i].phone}</td>
    `
    tbody.appendChild(tr);
}
}







//events 
fetchUsersButton.addEventListener('click',function(){
    getAllUsers();
    // tableAppendUser();
    console.log("happend");
    
});